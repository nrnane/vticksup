<?php

return array(
    // This variable is empty/null by default.
    // Only define it if the document root directory is not properly detected
    'documentRoot' => '',
);
