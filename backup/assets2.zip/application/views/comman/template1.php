<?php $this->load->view('comman/header.php'); ?>
<div class="container clearfix">
<?php $this->load->view($page); ?>
 </div> <!--End Container -->
<?php $this->load->view('comman/footer.php'); ?>