<div class="well">
    <a href="<?=site_url('admin/all_users')?>">View All Users</a>
</div>

<div class="well">
    <a href="<?=site_url('admin/all_projects')?>">View All Projects</a>
</div>

